import asyncio

async def sync_func1():
    print("Hello")
    await asyncio.sleep(3)
    print("Have a good day")

async def sync_func2():
    print("Bye")
    await asyncio.sleep(6)
    print("see you later")

async def main():
    coro1=sync_func1()
    coro2=sync_func2()
    result = await asyncio.gather(coro1, coro2)
    return result

print("Day Start")
asyncio.run(main())
print("Day End")