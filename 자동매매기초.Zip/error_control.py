price = {"open" : 100, "high" : 150, "low" : 90, "close" : 130}
print("point-1")
try:
    open = price["open1"]
except:
    pass
print("point-2")