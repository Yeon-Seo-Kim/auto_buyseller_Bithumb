import pybithumb

btc = pybithumb.get_ohlcv("BTC")
open = btc['open']
high = btc['high']
low = btc['low']
close = btc['close']
volume = btc['volume']
print(open)
print(high)
print(low)
print(close)
print(volume)