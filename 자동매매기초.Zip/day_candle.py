import pybithumb

df = pybithumb.get_ohlcv("BTC")
df['range']=(df['high'] - df['low']) * 0.5
df['range_shift_1']=df['range'].shift(1)
df['target'] = (df['open']+df['range']).shift(1)
df.to_excel("btc.xlsx")

#shift 는 한줄 아래로 내리는 역할