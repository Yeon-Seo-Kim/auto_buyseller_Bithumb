# 빗썸이 엿같은게 살때는 0.25% 물량 뺏어가고, 팔때는 0.25%만큼 돈 뺏어가고 미친놈들임 ㄹㅇ

import pybithumb
import numpy as np

def get_ror(k):
    df = pybithumb.get_ohlcv("BTC")
    df = df['2021']
    df['range'] = (df['high'] - df['low']) * k
    df['target'] = df['open'] + df['range'].shift(1)


    fee = 0.005549
    df['ror'] = np.where(df['high'] > df['target'], df['close'] / df['target'] - fee , 1)

    ror = df['ror'].cumprod()[-2]
    return ror

for k in np.arange(0.7250, 0.7350, 0.0001):
    ror = get_ror(k)
    print("%.1f %f" % (k,ror))