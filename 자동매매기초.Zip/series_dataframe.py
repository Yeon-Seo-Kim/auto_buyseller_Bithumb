from pandas import DataFrame
import pandas as pd
df = pd.read_excel("C:\\Users\yulki\PycharmProjects\pythonProject1\example_sheet1.xlsx")
df = df.set_index('date')
print(df)
df.to_excel("C:\\Users\yulki\PycharmProjects\pythonProject1\example_sheet_new.xlsx")