from pandas import Series
s = Series([100,200,300,400])
print(s / 100)