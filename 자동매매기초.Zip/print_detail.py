import pybithumb

detail = pybithumb.get_market_detail("BTC")
print(detail)

orderbook = pybithumb.get_orderbook("BTC")
print(orderbook)

for k in orderbook:
    print(k)
