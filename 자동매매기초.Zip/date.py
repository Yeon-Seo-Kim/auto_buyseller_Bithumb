import datetime

dt = datetime.datetime(2022, 1, 1)
now = datetime.datetime.now()
print(now)
print(dt)
print(dt.year, dt.month, dt.day)
print(now == dt)
print(now > dt)
mid = now + datetime.timedelta(1)
print(mid)