import pybithumb
import numpy as np

df = pybithumb.get_ohlcv("BTC")

df['ma5'] = df['close'].rolling(window = 5).mean().shift(1)
df['range'] = (df['high'] - df['low']) * 0.8
df['target'] = df['open'] + df['range'].shift(1)
df['bull'] = df['open'] > df['ma5']

fee = 0.005549
df['ror'] = np.where(df['high'] > df['target'], df['close'] / df['target'] - fee , 1)

df['hpr'] = df['ror'].cumprod()
df['dd'] = (df['hpr'].cummax() - df['hpr']) / df['hpr'].cummax() * 100
print("MDD(%): ",df['dd'].max())
print("HPR :",df['hpr'][-2])
df.to_excel("Larry_ma.xlsx")