from pandas import DataFrame
from pandas import Series

data = {"open":[730,750], "high":[755,780],"low":[700,710],"close":[750,770]}
df = DataFrame(data, index=["2018-08-01","2018-08-02"])
print(df["open"])
print(df.loc["2018-08-01"])
print(df.iloc[0])

target = ["2018-08-01","2018-08-02"]
print(df.loc[target])
target2 = [0,1]
print(df.iloc[target2])