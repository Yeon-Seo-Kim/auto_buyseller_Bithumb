import pybithumb

tickers = pybithumb.get_tickers()
print(tickers)
print(len(tickers))
price = pybithumb.get_current_price("BTC")
print(price)