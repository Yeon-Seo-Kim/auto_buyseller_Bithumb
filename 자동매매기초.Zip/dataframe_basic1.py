from pandas import DataFrame

data = {"open" : [100,200],"high" :[110,210],"low":[90,190],"close":[105,201]}
df = DataFrame(data , index=["2019-01-01","2019-01-02"])
print(df)