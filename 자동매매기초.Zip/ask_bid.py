import pybithumb

orderbook = pybithumb.get_orderbook("BTC")
bids = orderbook['bids']
asks = orderbook['asks']

for bid in bids:
    bid_price = bid['price']
    bid_quantity = bid['quantity']
    print("매수호가 :",bid_price, "매수잔량 :",bid_quantity)

for ask in asks:
    ask_price = ask['price']
    ask_quantity = ask['quantity']
    print("매도호가 :",ask_price, "매도잔량 :",ask_quantity)